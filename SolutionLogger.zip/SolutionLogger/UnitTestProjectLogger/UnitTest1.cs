﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WcfServiceLogger;

namespace UnitTestProjectLogger
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodLogger()
        {
            JobLogger log = new JobLogger(true, true, true, true, true, true);
            JobLogger.LogMessage("Pruebas JobLogger", false, true, false);
        }
    }
}
