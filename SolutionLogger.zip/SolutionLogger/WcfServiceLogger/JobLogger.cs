﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime;
using System.Web;

namespace WcfServiceLogger
{
    public class JobLogger
    {

        private static bool _logToFile;
        private static bool _logToConsole;
        private static bool _logMessage;
        private static bool _logWarning;
        private static bool _logError;
        private static bool LogToDatabase;
        private bool _initialized;

        public static string CadenaConexion = System.Configuration.ConfigurationManager.ConnectionStrings["ItemDBEntities"].ToString();


        public JobLogger(bool logToFile, bool logToConsole, bool logToDatabase, bool logMessage, bool logWarning, bool logError)
        {
            _logError = logError;
            _logMessage = logMessage;
            _logWarning = logWarning;
            LogToDatabase = logToDatabase;
            _logToFile = logToFile;
            _logToConsole = logToConsole;
        }

        public static void LogMessage(string message, bool mensajeVal, bool warning, bool error)
        {
            JobLogger log = new JobLogger(true, true, true, true, true, true);
            message.Trim();

            if (message == string.Empty || message.Length == 0)
            {
                return;
            }
            if (!_logToConsole && !_logToFile && !LogToDatabase)
            {
                throw new Exception("Invalid configuration");
            }
            if ((!_logError && !_logMessage && !_logWarning) || (!mensajeVal && !warning && !error))
            {
                throw new Exception("Error or Warning or Message must be specified");
            }


            int t = 0;
            string l = string.Empty;

            if (mensajeVal && _logMessage)
            {
                t = 1;
                l = DateTime.Now.ToShortDateString() + message;
                Console.ForegroundColor = ConsoleColor.White;
            }
            if (error && _logError)
            {
                t = 2;
                l = DateTime.Now.ToShortDateString() + " " + message;
                Console.ForegroundColor = ConsoleColor.Red;
            }
            if (warning && _logWarning)
            {
                t = 3;
                l = DateTime.Now.ToShortDateString() + message;
                Console.ForegroundColor = ConsoleColor.Yellow;
            }

            try
            {
                if (!System.IO.File.Exists(System.Configuration.ConfigurationManager.AppSettings["LogFileDirectory"] + "LogFile" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                {
                    var a = System.IO.File.Create(System.Configuration.ConfigurationManager.AppSettings["LogFileDirectory"] + "LogFile" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                    a.Close();
                    System.IO.File.WriteAllText(System.Configuration.ConfigurationManager.AppSettings["LogFileDirectory"] + "LogFile" + DateTime.Now.ToString("yyyyMMdd") + ".txt", l);
                    Console.WriteLine(DateTime.Now.ToShortDateString() + message);

                }
                else
                {
                    var text = System.IO.File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["LogFileDirectory"] + "LogFile" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                    System.IO.File.WriteAllText(System.Configuration.ConfigurationManager.AppSettings["LogFileDirectory"] + "LogFile" + DateTime.Now.ToString("yyyyMMdd") + ".txt", l);
                    Console.WriteLine(DateTime.Now.ToShortDateString() + message);
                }

                if (CadenaConexion != string.Empty)
                {
                    System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ItemDBEntities"].ToString());
                    connection.Open();
                    System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand("Insert into Log Values('" + message.ToString() + "', " + t.ToString() + ")", connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hubo un problema al intentar efectuar la operacion: " + ex.Message);
                Console.WriteLine("Detalle: " + ex.InnerException);
                Console.WriteLine("Seguimiento: " + ex.StackTrace);
            }


        }
    }

}
